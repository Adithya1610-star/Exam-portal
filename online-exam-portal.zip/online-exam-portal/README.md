# Online Exam Portal

A full-stack exam platform where students take timed multiple-choice tests, get instant scores and see a leaderboard.

## Tech stack
| Layer | Technology |
|-------|-----------|
| Frontend | HTML, CSS, JavaScript |
| Backend | Java 17, Spring Boot 3 (REST API) |
| SQL database | MySQL: exams and results |
| NoSQL database | MongoDB: question bank |

**Why two databases?** Exams and results are structured, relational data (MySQL). Questions have variable option lists, which suit flexible documents (MongoDB).

## Features
- Timed exams with auto-submit when the timer ends
- Automatic grading on the server (correct answers are never sent to the browser)
- Per-student result history
- Top-10 leaderboard per exam
- REST API to create exams and add questions
- Sample exam seeded on first run

## Setup
1. Install JDK 17+, Maven, MySQL and MongoDB.
2. Start MySQL and MongoDB.
3. Edit `src/main/resources/application.properties` with your MySQL username and password.
4. Run:
   ```bash
   mvn spring-boot:run
   ```
5. Open http://localhost:8080

## API
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/exams` | List exams |
| POST | `/api/exams` | Create exam `{title, durationMinutes}` |
| GET | `/api/exams/{id}/questions` | Questions without answers |
| POST | `/api/exams/{id}/questions` | Add question `{text, options[], correctIndex}` |
| POST | `/api/exams/{id}/submit` | Submit `{studentName, answers:{questionId: optionIndex}}` |
| GET | `/api/results?student=NAME` | A student's results |
| GET | `/api/exams/{id}/leaderboard` | Top 10 scores |

Example: add a question
```bash
curl -X POST http://localhost:8080/api/exams/1/questions \
  -H "Content-Type: application/json" \
  -d '{"text":"2+2?","options":["3","4","5"],"correctIndex":1}'
```

## Project structure
```
src/main/java/com/examportal/
  controller/   REST endpoints
  model/        JPA entities, Mongo document, DTOs
  repository/   MySQL and MongoDB repositories
  config/       sample data seeder
src/main/resources/
  static/       frontend (index.html, style.css, app.js)
  application.properties
docs/           add your report, ER diagram, screenshots here
```

## Future improvements
- Login with roles (admin / student) using Spring Security and JWT
- Admin page for creating exams from the UI
- Question randomisation and result PDF export

## License
MIT
