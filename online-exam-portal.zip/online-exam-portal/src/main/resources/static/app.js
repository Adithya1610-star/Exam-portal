const API = "/api";
const $ = (id) => document.getElementById(id);

let currentExam = null;
let questions = [];
let timerId = null;

function esc(s) {
  const d = document.createElement("div");
  d.textContent = s;
  return d.innerHTML;
}

function show(section) {
  ["home", "exam", "result"].forEach((id) => $(id).classList.toggle("hidden", id !== section));
}

async function api(path, options) {
  const res = await fetch(API + path, options);
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.message || "Request failed");
  }
  return res.json();
}

async function loadExams() {
  const exams = await api("/exams");
  $("exam-list").innerHTML = exams.length
    ? exams.map((e) => `
        <div class="exam-item">
          <span>${esc(e.title)} (${e.durationMinutes} min)</span>
          <button data-id="${e.id}">Start</button>
        </div>`).join("")
    : "<p>No exams yet.</p>";
  document.querySelectorAll("#exam-list button").forEach((b) => {
    b.onclick = () => startExam(exams.find((e) => e.id == b.dataset.id));
  });
}

async function startExam(exam) {
  if (!$("name").value.trim()) { alert("Please enter your name first."); return; }
  currentExam = exam;
  questions = await api(`/exams/${exam.id}/questions`);
  if (!questions.length) { alert("This exam has no questions yet."); return; }
  $("exam-title").textContent = exam.title;
  $("questions").innerHTML = questions.map((q, i) => `
    <div class="question">
      <p>${i + 1}. ${esc(q.text)}</p>
      ${q.options.map((o, j) => `
        <label class="option">
          <input type="radio" name="q_${q.id}" value="${j}"> ${esc(o)}
        </label>`).join("")}
    </div>`).join("");
  show("exam");
  startTimer(exam.durationMinutes * 60);
}

function startTimer(seconds) {
  clearInterval(timerId);
  const tick = () => {
    const m = String(Math.floor(seconds / 60)).padStart(2, "0");
    const s = String(seconds % 60).padStart(2, "0");
    $("timer").textContent = `${m}:${s}`;
    if (seconds-- <= 0) { clearInterval(timerId); submitExam(); }
  };
  tick();
  timerId = setInterval(tick, 1000);
}

async function submitExam() {
  clearInterval(timerId);
  const answers = {};
  questions.forEach((q) => {
    const picked = document.querySelector(`input[name="q_${q.id}"]:checked`);
    if (picked) answers[q.id] = Number(picked.value);
  });
  try {
    const result = await api(`/exams/${currentExam.id}/submit`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ studentName: $("name").value.trim(), answers }),
    });
    $("score").textContent = `You scored ${result.score} / ${result.total}`;
    const board = await api(`/exams/${currentExam.id}/leaderboard`);
    $("leaderboard").innerHTML = board
      .map((r) => `<li>${esc(r.studentName)} - ${r.score}/${r.total}</li>`).join("");
    show("result");
  } catch (e) {
    alert(e.message);
  }
}

async function showMyResults() {
  const name = $("name").value.trim();
  if (!name) { alert("Enter your name first."); return; }
  const rows = await api(`/results?student=${encodeURIComponent(name)}`);
  $("my-results").innerHTML = rows.length
    ? `<table><tr><th>Exam ID</th><th>Score</th><th>Date</th></tr>${rows.map((r) => `
        <tr><td>${r.examId}</td><td>${r.score}/${r.total}</td>
        <td>${new Date(r.submittedAt).toLocaleString()}</td></tr>`).join("")}</table>`
    : "<p>No results yet.</p>";
}

$("submit-btn").onclick = submitExam;
$("my-results-btn").onclick = showMyResults;
$("back-btn").onclick = () => { show("home"); loadExams(); };
loadExams();
