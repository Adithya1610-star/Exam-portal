package com.examportal.repository;

import com.examportal.model.Question;
import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface QuestionRepository extends MongoRepository<Question, String> {
    List<Question> findByExamId(Long examId);
}
