package com.examportal.repository;

import com.examportal.model.ExamResult;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ResultRepository extends JpaRepository<ExamResult, Long> {
    List<ExamResult> findByStudentNameIgnoreCaseOrderBySubmittedAtDesc(String studentName);
    List<ExamResult> findTop10ByExamIdOrderByScoreDescSubmittedAtAsc(Long examId);
}
