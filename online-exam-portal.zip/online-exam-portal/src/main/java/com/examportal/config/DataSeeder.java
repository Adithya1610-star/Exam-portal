package com.examportal.config;

import com.examportal.model.Exam;
import com.examportal.model.Question;
import com.examportal.repository.ExamRepository;
import com.examportal.repository.QuestionRepository;
import java.util.List;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/** Adds a sample exam on first run so the app is not empty. */
@Component
public class DataSeeder implements CommandLineRunner {

    private final ExamRepository exams;
    private final QuestionRepository questions;

    public DataSeeder(ExamRepository exams, QuestionRepository questions) {
        this.exams = exams;
        this.questions = questions;
    }

    @Override
    public void run(String... args) {
        if (exams.count() > 0) return;

        Exam exam = new Exam();
        exam.setTitle("Java Basics");
        exam.setDurationMinutes(5);
        exam = exams.save(exam);

        add(exam.getId(), "Which keyword is used to inherit a class in Java?",
                List.of("implements", "extends", "inherits", "super"), 1);
        add(exam.getId(), "Which collection does not allow duplicate elements?",
                List.of("ArrayList", "LinkedList", "HashSet", "Vector"), 2);
        add(exam.getId(), "What is the default value of an int instance variable?",
                List.of("null", "0", "1", "undefined"), 1);
        add(exam.getId(), "Which of these is NOT a primitive type in Java?",
                List.of("int", "boolean", "String", "char"), 2);
    }

    private void add(Long examId, String text, List<String> options, int correct) {
        Question q = new Question();
        q.setExamId(examId);
        q.setText(text);
        q.setOptions(options);
        q.setCorrectIndex(correct);
        questions.save(q);
    }
}
