package com.examportal.model;

import java.util.Map;

/** answers: questionId -> chosen option index. */
public record SubmitRequest(String studentName, Map<String, Integer> answers) {}
