package com.examportal.model;

import java.util.List;

/** What the student sees: the question without the correct answer. */
public record QuestionView(String id, String text, List<String> options) {
    public static QuestionView from(Question q) {
        return new QuestionView(q.getId(), q.getText(), q.getOptions());
    }
}
