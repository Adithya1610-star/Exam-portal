package com.examportal.controller;

import com.examportal.model.*;
import com.examportal.repository.*;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api")
public class ExamController {

    private final ExamRepository exams;
    private final ResultRepository results;
    private final QuestionRepository questions;

    public ExamController(ExamRepository exams, ResultRepository results, QuestionRepository questions) {
        this.exams = exams;
        this.results = results;
        this.questions = questions;
    }

    @GetMapping("/exams")
    public List<Exam> listExams() {
        return exams.findAll();
    }

    @PostMapping("/exams")
    @ResponseStatus(HttpStatus.CREATED)
    public Exam createExam(@RequestBody Exam exam) {
        if (exam.getTitle() == null || exam.getTitle().isBlank() || exam.getDurationMinutes() <= 0) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Title and a positive duration are required");
        }
        exam.setId(null);
        return exams.save(exam);
    }

    @GetMapping("/exams/{id}/questions")
    public List<QuestionView> examQuestions(@PathVariable Long id) {
        requireExam(id);
        return questions.findByExamId(id).stream().map(QuestionView::from).toList();
    }

    @PostMapping("/exams/{id}/questions")
    @ResponseStatus(HttpStatus.CREATED)
    public Question addQuestion(@PathVariable Long id, @RequestBody Question q) {
        requireExam(id);
        if (q.getText() == null || q.getText().isBlank() || q.getOptions() == null || q.getOptions().size() < 2
                || q.getCorrectIndex() < 0 || q.getCorrectIndex() >= q.getOptions().size()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid question");
        }
        q.setId(null);
        q.setExamId(id);
        return questions.save(q);
    }

    @PostMapping("/exams/{id}/submit")
    public ExamResult submit(@PathVariable Long id, @RequestBody SubmitRequest req) {
        requireExam(id);
        if (req.studentName() == null || req.studentName().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Student name is required");
        }
        List<Question> qs = questions.findByExamId(id);
        int score = 0;
        for (Question q : qs) {
            Integer chosen = req.answers() == null ? null : req.answers().get(q.getId());
            if (chosen != null && chosen == q.getCorrectIndex()) {
                score++;
            }
        }
        ExamResult r = new ExamResult();
        r.setStudentName(req.studentName().trim());
        r.setExamId(id);
        r.setScore(score);
        r.setTotal(qs.size());
        return results.save(r);
    }

    @GetMapping("/results")
    public List<ExamResult> myResults(@RequestParam String student) {
        return results.findByStudentNameIgnoreCaseOrderBySubmittedAtDesc(student.trim());
    }

    @GetMapping("/exams/{id}/leaderboard")
    public List<ExamResult> leaderboard(@PathVariable Long id) {
        requireExam(id);
        return results.findTop10ByExamIdOrderByScoreDescSubmittedAtAsc(id);
    }

    private void requireExam(Long id) {
        if (!exams.existsById(id)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Exam not found");
        }
    }
}
