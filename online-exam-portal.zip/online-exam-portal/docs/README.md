Put your project report, architecture diagram, ER diagram, PPT and UI screenshots in this folder.
